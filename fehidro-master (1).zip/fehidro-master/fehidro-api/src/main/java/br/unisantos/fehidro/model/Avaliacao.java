package br.unisantos.fehidro.model;

import javax.persistence.Entity;
import javax.persistence.Table;

@Table(name = "tb_avaliacao")
@Entity
public class Avaliacao  extends AbstractEntity {
	private static final long serialVersionUID = 1L;

}
