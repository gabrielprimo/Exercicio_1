package fehidro.rest.client;

import java.util.List;

import fehidro.model.Usuario;
import fehidro.rest.client.RESTClientInterface;

public class UsuarioRESTClient implements RESTClientInterface<Usuario>{

	@Override
	public List<Usuario> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Usuario find(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Usuario create(Usuario obj) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Usuario edit(Usuario obj) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean delete(Long id) {
		// TODO Auto-generated method stub
		return false;
	}

}
